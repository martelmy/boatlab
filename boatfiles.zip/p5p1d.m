T_s = 0.1;
simconst = 2000;
K = 0.156104151159624;
T = 72.570764269542470;

sim('sp5p1d.mdl',0:T_s:simconst);
H_psi = tf(K, [T 1 0]);
model = step(H_psi,compass.time);
plot(compass.time, compass.data,'b');
hold on 
grid on
plot(compass.time, model, 'r');
axis([0 1000 -100 200])
xlabel('time');
ylabel('angle [deg]');
legend('ship response','model response');
%saveas(gcf,'5_1dstep_mod_ship','epsc');
hold off
plot(y.data, x.data);
grid on
axis([-1000 6000 -3000 4000])
xlabel('x-axis')
ylabel('y-axis')
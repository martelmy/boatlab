load('wave.mat')
simconst = 2000;
T_s = 0.1;
omega_1 = 0.005;
omega_2 = 0.05;
%%
omega = omega_1;
sim('sp5p1c.mdl');
plot(compass.time,compass.data);
grid on
xlabel('time')
ylabel('compass [deg]')
%saveas(gcf,'5_1c_w1','epsc')
%%
omega = omega_2;
sim('sp5p1c.mdl');
plot(compass.time,compass.data);
grid on
xlabel('time')
ylabel('compass [deg]')
%saveas(gcf,'5_1c_w2','epsc')

load('wave.mat')
%5.2a
%PSD estimator
clf;
fs = 10;
window = 4096;
[pxx,f] = pwelch(psi_w(2,:).*pi/180, window, [], [], fs);  
pxx = pxx/(2*pi);
f = f*2*pi;

%5.2b ->
plot(f, pxx, 'b');
xlabel('f');
ylabel('pxx');
axis([0 3 0 0.0016]);
grid on;
hold on;

% Actual SPD eq
pxx_max = max(pxx);
sigma = sqrt(pxx_max);
omega_0 = 0.7823;
lambda = 0.075;
q = 1;
K_w = 2*lambda*omega_0*sigma;
P = @(omega)(omega^2*K_w^2*q)/((omega_0^2 - omega^2)^2+(omega*2*lambda*omega_0)^2);
fplot (P, 'r');
xlabel('\omega');
ylabel('S, P');
legend('S', 'P')
grid on;
%saveas(gcf,'5_2d','epsc');

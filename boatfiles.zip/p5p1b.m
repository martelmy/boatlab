load('wave.mat')
simconst = 2000;
T_s = 0.1;
omega_1 = 0.005;
omega_2 = 0.05;
%%
omega = omega_1;
sim('sp5p1b.mdl');
plot(compass.time,compass.data);
grid on
xlabel('time')
ylabel('compass [deg]')
%saveas(gcf,'5_1b_w1','epsc')
%%
omega = omega_2;
sim('sp5p1b.mdl');
plot(compass.time,compass.data);
grid on
xlabel('time')
ylabel('compass [deg]')
%saveas(gcf,'5_1b_w2','epsc')
%%
ampl1 = 29.3485;
ampl2 = 0.8295;
%%
T = sqrt((ampl2^2*omega_2^2 - ampl1^2*omega_1^2)/(ampl1^2*omega_1^4 - ampl2^2*omega_2^4));
K = omega_1*ampl1*sqrt((T*omega_1)^2+1);
% Discretizing the system
T = 72.570764269542470;
K = 0.156104151159624;
lambda = 0.075;
omega_0 = 0.7823;
K_w = 0.004520767970384;

psi_r = 30;
T_d = T;
omega_c = 0.1;
pm = 50*pi/180;
T_f = -1/(omega_c*tan(pi-pm));
K_pd = (omega_c*sqrt(1+(T_f*omega_c)^2))/K;

A = [0 1 0 0 0; -omega_0^2 -2*lambda*omega_0 0 0 0;
    0 0 0 1 0; 0 0 0 -1/T -1/K; 0 0 0 0 0];
B = [0; 0; 0; K/T; 0];
C = [0 1 1 0 0];
E = [0 0; K_w 0; 0 0; 0 0; 0 1];
fs = 10;
T_s = 1/fs;

[A_d, B_d] = c2d(A,B,T_s);
[A_d, E_d] = c2d(A,E,T_s);

% Finding an estimate
estimate_var = 6.013282621421814e-07;

%Simulating system with Kalman Filtering
simconst = 700;
R = estimate_var*fs;
x0 = [0; 0; 0; 0; 0];
Q = [30 0; 0 1e-06];
P0 = [1 0 0 0 0; 0 0.013 0 0 0; 0 0 pi^2 0 0; 0 0 0 1 0; 0 0 0 0 2.5e-03];
system = struct('A_d', A_d, 'B_d', B_d, 'C_d', C, 'E_d', E_d, ...
    'x_pri', x0, 'P_pri', P0, 'Q', Q, 'R', R);

sim('sp5p5e.mdl')
hold on
plot(compass.time,compass.data,'g')
plot(compass_filt.time,compass_filt.data,'m')
plot(reference.time,reference.data,'--r')
grid on
xlabel('time')
ylabel('angle [deg]')
%saveas(gcf,'5_5emesfiltcompass','epsc')




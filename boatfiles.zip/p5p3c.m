T = 72.570764269542470;
K = 0.156104151159624;

psi_r = 30;
T_d = T;
omega_c = 0.1;
pm = 50*pi/180;
T_f = -1/(omega_c*tan(pi-pm));
K_pd = (omega_c*sqrt(1+(T_f*omega_c)^2))/K;
simconst = 500;

sim('sp5p3c.mdl');
plot(compass.time, compass.data);
grid on
xlabel('time')
ylabel('angle [deg]')
%saveas(gcf,'5_3ccomp','epsc')

plot(rudder_inp.time, rudder_inp.data);
grid on
xlabel('time')
ylabel('angle [deg]')
%saveas(gcf,'5_3crud','epsc')

plot(y.data, x.data);
grid on
xlabel('time')
ylabel('angle [deg]')
axis([-5000 5000 -5000 5000])
%saveas(gcf,'5_3cNE','epsc')